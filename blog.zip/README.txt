The name of database is "blog".
Import the sql file into the database.